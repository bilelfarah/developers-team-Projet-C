#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "troupeau.h"
#include <gtk/gtk.h>

enum {
IDENTIFIANT,
TYPE,
SEXE, 
NOURRITURE, 
ETAT, 
DATE,
COLUMNS
};


//affichage 
consulter (GtkWidget *liste){
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char etat[10];
char ID[10] ; 
char type [50];
char date [50];
char nourriture[10]; 
char sexe[10]; 
int jour;
int mois;
int an; 
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL){



renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",IDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nourriture",renderer,"text",NOURRITURE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Etat", renderer, "text",ETAT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date de naissance",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
//

f=fopen ("troupeau.txt","r");
if (f==NULL){return;}
else {
f=fopen("troupeau.txt","a+");
while (fscanf (f," %s %s %s %s %s %d %d %d",ID,type,sexe,nourriture,etat,&jour,&mois,&an)!=EOF)
{ 
sprintf(date,"%d/%d/%d",jour,mois,an);	
gtk_list_store_append(store, &iter);
gtk_list_store_set (store, &iter, IDENTIFIANT, ID, TYPE, type, SEXE, sexe, NOURRITURE, nourriture,ETAT, etat,DATE,date, -1);  }

fclose (f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);  
 }}}















