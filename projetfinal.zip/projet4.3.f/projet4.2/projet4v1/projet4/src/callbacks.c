#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "employe.h"
#include "personne.h"
#include "absentisme.h"
#include "login.h"
#include "admin.h"
#include "troupeau.h"
#include "client.h"
#include "capteur.h"
#include "parametres.h"

int x=0;
int t[2]={0,0};
int t1[50];


int x;
int y;
int a;
void
on_ajouter_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
employe e;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input8,*profession;	
GtkWidget *ajout_emp;


ajout_emp=lookup_widget(objet_graphique,"ajout_emp");	
input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2");
input3=lookup_widget(objet_graphique,"entry3");
input4=lookup_widget(objet_graphique,"entry4");
input5=lookup_widget(objet_graphique,"entry5");
input6=lookup_widget(objet_graphique,"entry6");
input8=lookup_widget(objet_graphique,"entry8");
profession=lookup_widget(objet_graphique,"entry9");

strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.dnaissance,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.email,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.login,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(e.mdp,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(e.profession,gtk_combo_box_get_active_text(GTK_COMBO_BOX(profession)));
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input8)));

if(x==0)
{strcpy(e.sexe,"Homme");}
else
if(x==1)
{strcpy(e.sexe,"Femme");}
ajouter_employe(e);
}


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *ajout_emp;
GtkWidget *affiche_emp;
GtkWidget *treeview1;


ajout_emp=lookup_widget(objet,"ajout_emp");
gtk_widget_destroy(ajout_emp);
affiche_emp=lookup_widget(objet,"affiche_emp");
affiche_emp=create_affiche_emp();
gtk_widget_show(affiche_emp);
treeview1=lookup_widget(affiche_emp,"treeview1");
afficher_employe(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{		GtkTreeIter iter;
		gchar* id;
		gchar* nom;
		gchar* prenom;
		gchar* dnaissance;
		gchar* email;
		gchar* login;
		gchar* mdp;
		gchar* sexe;
		gchar* profession;
		employe e;
		int id1;
		
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
	gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&prenom,3,&dnaissance,4,&email,5,&login,6,&mdp,7,&sexe,8,&profession,-1);
	strcpy(e.id,id);
	strcpy(e.nom,nom);
	strcpy(e.prenom,prenom);
	strcpy(e.dnaissance,dnaissance);
	strcpy(e.email,email);
	strcpy(e.login,login);
	strcpy(e.mdp,mdp);
	strcpy(e.sexe,sexe);
	strcpy(e.profession,profession);

afficher_employe(treeview);

}}

void
on_retouremp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)

{GtkWidget *ajout_emp,*affiche_emp;
affiche_emp=lookup_widget(objet,"affiche_emp");
gtk_widget_destroy(affiche_emp);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);}



void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)

{GtkWidget *ajout_emp,*supprim_emp;
GtkWidget *combo;
	FILE *f;
	char id[30];
ajout_emp=lookup_widget(objet,"ajout_emp");
gtk_widget_destroy(ajout_emp);
supprim_emp=create_supprim_emp();
combo=lookup_widget(supprim_emp,"cb_supprimer_emp");
	f=fopen("employe.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s %*s %*s\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(supprim_emp);
}



void
on_retour_supp_emp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
{
GtkWidget *supprim_emp,*ajout_emp; 
supprim_emp=lookup_widget(objet,"supprim_emp");
gtk_widget_destroy(supprim_emp);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);
}
}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)

{
GtkWidget *ajout_emp,*modif_emp;
GtkWidget *combo;
	FILE *f;
	char id[30];
ajout_emp=lookup_widget(objet,"ajout_emp");
gtk_widget_destroy(ajout_emp);
modif_emp=create_modif_emp();
combo=lookup_widget(modif_emp,"cb_modif_emp");
	f=fopen("employe.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s %*s %*s\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(modif_emp);
}

void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)

{	employe e;
GtkWidget *input;
input= lookup_widget(objet,"cb_supprimer_emp");
strcpy(e.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
Supprimer_employe(e);
}


void
on_retour_modif_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)

{GtkWidget *modif_emp,*ajout_emp;
modif_emp=lookup_widget(objet,"modif_emp");
gtk_widget_destroy(modif_emp);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);}


void
on_modif_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
employe e;
GtkWidget *modif_emp; 	
GtkWidget *id,*nom,*prenom,*dnaissance,*email,*login,*mdp,*sexe,*profession;
modif_emp=lookup_widget(objet_graphique,"modif_emp");
id= lookup_widget(objet_graphique,"cb_modif_emp");
nom= lookup_widget(objet_graphique,"mentry1");
prenom= lookup_widget(objet_graphique,"mentry2");
dnaissance=lookup_widget(objet_graphique,"mentry3");
email=lookup_widget(objet_graphique,"mentry4");
login=lookup_widget(objet_graphique,"mentry5");
mdp=lookup_widget(objet_graphique,"mentry6");
sexe=lookup_widget(objet_graphique,"mentry7");
profession=lookup_widget(objet_graphique,"mentry9");

strcpy(e.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.dnaissance,gtk_entry_get_text(GTK_ENTRY(dnaissance)));
strcpy(e.email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(e.login,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(e.mdp,gtk_entry_get_text(GTK_ENTRY(mdp)));
strcpy(e.sexe,gtk_entry_get_text(GTK_ENTRY(sexe)));
strcpy(e.profession,gtk_combo_box_get_active_text(GTK_COMBO_BOX(profession)));



Modifier_employe(e);
}

  
void
on_radiobutton1_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=0;
}
}
void
on_radiobutton2_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}




void
on_Connexion_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
int verif;
 
  char password[20];
  char login[20];
  GtkWidget *input11;
  GtkWidget *input22;
  GtkWidget *Admin;
  GtkWidget *ajout_emp;
  GtkWidget *output2;
  GtkWidget *authentification;
GtkWidget *trconsulter2;
  input11=lookup_widget(objet_graphique,"entrylogin");
  input22=lookup_widget(objet_graphique,"entrypassword");
  output2=lookup_widget(objet_graphique,"label100");
  strcpy(login, gtk_entry_get_text(GTK_ENTRY(input11)));
  strcpy(password, gtk_entry_get_text(GTK_ENTRY(input22)));
  printf("%s\n",login );
  printf("%s\n",password );
verif = verifierlogin(login,password);

if (verif==3)
{
trconsulter2= create_trconsulter2 ();
gtk_widget_show (trconsulter2);
authentification=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy (authentification);
}

 
if(verif == -1)
{
  gtk_label_set_text(GTK_LABEL(output2), "Username ou mot de passe incorrect !");

}
else if(verif==1)
{
  Admin= create_Admin ();
  gtk_widget_show (Admin);

  authentification=lookup_widget(objet_graphique,"authentification");
  gtk_widget_destroy (authentification);
}
else if(verif==2)
{
  ajout_emp= create_ajout_emp ();
  gtk_widget_show (ajout_emp);

  authentification=lookup_widget(objet_graphique,"authentification");
  gtk_widget_destroy (authentification);
}
}


void
on_Ajout_admin_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)

{GtkWidget *Admin,*ajout_emp; 
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);
}


void
on_Modifier_admin_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Admin,*modif_emp;
GtkWidget *combo;
FILE *f;

	char id[30];
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
modif_emp=create_modif_emp();
combo=lookup_widget(modif_emp,"cb_modif_emp");
	f=fopen("employe.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s %*s %*s\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(modif_emp);
}


void
on_Supprimer_admin_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Admin,*supprim_emp;
GtkWidget *combo;
	FILE *f;
	char id[30];
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
supprim_emp=create_supprim_emp();
combo=lookup_widget(supprim_emp,"cb_supprimer_emp");
	f=fopen("employe.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s %*s %*s\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(supprim_emp);
}


void
on_Afficher_admin_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Admin;
GtkWidget *affiche_emp;
GtkWidget *treeview1;


Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
affiche_emp=lookup_widget(objet,"affiche_emp");
affiche_emp=create_affiche_emp();
gtk_widget_show(affiche_emp);
treeview1=lookup_widget(affiche_emp,"treeview1");
afficher_employe(treeview1);
}


void
on_retour_admin_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Admin,*authentification;
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
authentification=create_authentification();
gtk_widget_show(authentification);
}


void
on_Inscription_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *authentification,*Inscription;
authentification=lookup_widget(objet,"authentification");
gtk_widget_destroy(authentification);
Inscription=create_Inscription();
gtk_widget_show(Inscription);
}


void
on_enregistrer_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *entry_ea_nom;
  GtkWidget *entry_ea_prenom;
  GtkWidget *entry_ea_login;
  GtkWidget *entry_ea_mdp;
  GtkWidget *entry_ea_tel;
 GtkWidget *output;
 GtkWidget *authentification;
  GtkWidget *Inscription;
    char name1[20]; char last1[20];char tel1[20];char username1[20]; char password1[20];
 entry_ea_nom = lookup_widget(objet_graphique, "entry_ea_nom");
 entry_ea_prenom = lookup_widget(objet_graphique, "entry_ea_prenom");
 entry_ea_login = lookup_widget(objet_graphique, "entry_ea_login");
 entry_ea_mdp = lookup_widget(objet_graphique, "entry_ea_mdp");
 entry_ea_tel = lookup_widget(objet_graphique, "entry_ea_tel");
output= lookup_widget(objet_graphique, "label101");
 strcpy(last1, gtk_entry_get_text(GTK_ENTRY(entry_ea_nom)));
 strcpy(name1, gtk_entry_get_text(GTK_ENTRY(entry_ea_prenom)));
  strcpy(username1, gtk_entry_get_text(GTK_ENTRY(entry_ea_login)));
   strcpy(password1, gtk_entry_get_text(GTK_ENTRY(entry_ea_mdp)));
    strcpy(tel1, gtk_entry_get_text(GTK_ENTRY(entry_ea_tel)));
   if (verifierexistant(username1)== 0)
    {
        gtk_label_set_text(GTK_LABEL(output), "Nom d'utilsateur déjà utilisé !");
    }
  else
 { personne p;
   strcpy(p.nom,name1);
    strcpy(p.prenom,last1);
    strcpy(p.username,username1);
    strcpy(p.password,password1);
    strcpy(p.tel,tel1);
    ajouter_c(p);
    
  authentification= create_authentification ();
  gtk_widget_show (authentification);
  Inscription=lookup_widget(objet_graphique,"Inscription");
  gtk_widget_destroy (Inscription);

  }
}


void
on_retour_inscri_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Inscription,*authentification; 
Inscription=lookup_widget(objet,"Inscription");
gtk_widget_destroy(Inscription);
authentification=create_authentification();
gtk_widget_show(authentification);
}


void
on_deconnexion_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajout_emp,*authentification; 
ajout_emp=lookup_widget(objet,"ajout_emp");
gtk_widget_destroy(ajout_emp);
authentification=create_authentification();
gtk_widget_show(authentification);
}


void
on_ajouter_admin_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
admin a;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input8,*input7;	
GtkWidget *ajout_admin;


ajout_admin=lookup_widget(objet_graphique,"ajout_admin");	
input1=lookup_widget(objet_graphique,"entryadmin1");
input2=lookup_widget(objet_graphique,"entryadmin2");
input3=lookup_widget(objet_graphique,"entryadmin3");
input4=lookup_widget(objet_graphique,"entryadmin4");
input5=lookup_widget(objet_graphique,"entryadmin5");
input6=lookup_widget(objet_graphique,"entryadmin6");
input7=lookup_widget(objet_graphique,"entryadmin7");
input8=lookup_widget(objet_graphique,"entryadmin8");



strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(a.dnaissance,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(a.email,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(a.login,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(a.mdp,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(a.telephone,gtk_entry_get_text(GTK_ENTRY(input8)));

ajouter_admin(a);
}


void
on_retour_admin1_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajout_admin,*Admin; 
ajout_admin=lookup_widget(objet,"ajout_admin");
gtk_widget_destroy(ajout_admin);
Admin=create_Admin();
gtk_widget_show(Admin);
}
void
on_button3_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajout_admin,*Admin; 
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
ajout_admin=create_ajout_admin();
gtk_widget_show(ajout_admin);
}


void
on_Valider_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
ouv n;
    GtkWidget *absent;
    GtkWidget *id,*jour,*mois,*annee;
    


id=lookup_widget(objet,"combobox1_absent");
absent=lookup_widget(objet,"absent");
jour=lookup_widget(objet,"jours");
mois=lookup_widget(objet,"mois");
annee=lookup_widget(objet,"annee");

	
strcpy(n.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
n.date_abs.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_abs.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_abs.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(a==0)
{strcpy(n.abs,"Present");}
else
if(a==1)
{strcpy(n.abs,"Absent");}
absentisme(n);
}


void
on_Abseent_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *absent,*ajout_emp; 
GtkWidget *combo;
char id[30];
FILE *f;
ajout_emp=lookup_widget(objet,"ajout_emp");
gtk_widget_destroy(ajout_emp);
absent=create_absent();
combo=lookup_widget(absent,"combobox1_absent");
f=fopen("employe.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s %*s %*s\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);	

gtk_widget_show(absent);
}


void
on_treeview2_absent_row_activated      (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
   GtkTreeIter iter;
	gchar* id;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* abs;	

	ouv n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview1);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &id, 1, &jour, 2,  &mois , 3, &annee, 4, &abs ,-1);
  		strcpy(n.id,id);
		strcpy(n.abs,abs);
                n.date_abs.jour=jour;
                n.date_abs.mois=mois;
                n.date_abs.annee=annee;
                affich_absent(treeview1);
	}
}


void
on_affiche_absent_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
	ouv n;
   GtkWidget *absent;
   GtkWidget *idm;
   GtkWidget *treeview2_absent;
  
   
   char idouv[20];


absent=lookup_widget(objet,"absent");
idm=lookup_widget(objet,"entryabsent");
treeview2_absent=lookup_widget(objet,"treeview2_absent");

strcpy(idouv,gtk_entry_get_text(GTK_ENTRY(idm)));
strcpy(n.id,idouv);
affich_id(treeview2_absent, idouv);

}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
a=0;
}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
a=1;
}
}



void
on_Retour_absentisme_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *absent,*ajout_emp; 
absent=lookup_widget(objet,"absent");
gtk_widget_destroy(absent);
ajout_emp=create_ajout_emp();
gtk_widget_show(ajout_emp);
}


void
on_calcul_absent_mois_clicked          (GtkButton       *button,
                                        gpointer         user_data)

{
 GtkWidget *absent;
   GtkWidget *output;
   GtkWidget *idm;
   GtkWidget *treeview2_absent;
GtkWidget *jour,*mois,*annee;
ouv n;
int nb=0,nb1=0;
float taux;
char texte [200]="";
char  id1[20];
n.date_abs.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_abs.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_abs.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
output=lookup_widget(button,"label120");
idm=lookup_widget(button,"entryabsent");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(idm)));

FILE *f =NULL;
 
f= fopen ("absentisme.txt","r");
if (f!= NULL)
{ 
while (fscanf (f,"%s %s %s %s %s \n",n.id,n.date_abs.jour,n.date_abs.mois,n.date_abs.annee,n.abs)!=EOF)

{ if (strcmp(n.abs,"Absent")==0)
{nb+=1;}
{nb1+=1;}
taux=(nb/(nb+nb1))*100;
}
sprintf (texte,"Le taux abscence de cette identifiant est: %f %",taux);
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
return (taux);
}}

/*{  ouv n;
   GtkWidget *absent;
   GtkWidget *output;
   GtkWidget *idm;
   GtkWidget *treeview2_absent;
GtkWidget *jour,*mois,*annee;
int x=0;
int y=0;
char z[200];
char id1[20];
float taux;

FILE *f=NULL;
f=fopen("employe.txt","r");
FILE *f1=NULL;
f1=fopen("absenteisme.txt","r");
int tot=0,jj,mm,an,val,nabs=0;
float taux;
char matricule[20];
while (fscanf(f,"\n")!=EOF)
{tot++;}
while (fscanf(f1,"%s %d %d %d %d \n",matricule,jj,mm,an,val)!=EOF)
{if (mm==mois)&&(aa==an)&&(val==0)){nabs++;}}
taux=nabs*100/(30*tot);
return taux;
}

}

printf("le taux absentisme de cette id est %f %",taux);
gtk_label_set_text(GTK_LABEL(output),z);*/




////////////////////troupeau
void
on_FKretour1_clicked                   (GtkWidget      *widget,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrajouter,  *treeviewtr2;

windowtrajouter=lookup_widget(widget,"windowtrajouter");

gtk_widget_destroy(windowtrajouter);
windowtrgestion0=lookup_widget(widget,"windowtrgestion0");
windowtrgestion0=create_trgestion0();
gtk_widget_show(windowtrgestion0);

treeviewtr2=lookup_widget(windowtrgestion0,"treeviewtr2");

consulter (treeviewtr2);
}
void
on_FKajouter0_clicked                 (GtkWidget      *widget,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrajouter,  *treeview1;
windowtrgestion0=lookup_widget(widget,"windowtrgestion0");
gtk_widget_hide(windowtrgestion0);
windowtrajouter=create_trajouer ();
gtk_widget_show (windowtrajouter);
}


void
on_FKsuprimer0_clicked                 (GtkWidget      *widget,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrsuprimer0,  *treeviewtr3;
windowtrgestion0=lookup_widget(widget,"windowtrgestion0");
gtk_widget_hide(windowtrgestion0);
windowtrsuprimer0=create_trsupprimer3();
gtk_widget_show (windowtrsuprimer0);
treeviewtr3=lookup_widget(windowtrsuprimer0,"treeviewtr3");

consulter (treeviewtr3);
}


void
on_FKconsulter0_clicked                (GtkWidget      *widget,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrconsulter2,  *treeviewtr1;
windowtrgestion0=lookup_widget(widget,"windowtrgestion0");
gtk_widget_hide(windowtrgestion0);
windowtrconsulter2=create_trconsulter2();
gtk_widget_show (windowtrconsulter2);

treeviewtr1=lookup_widget(windowtrconsulter2, "treeviewtr1" );
consulter (treeviewtr1);

}


void
on_FKmodifier0_clicked                 (GtkWidget      *widget,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrmodifier0, *combo;

	FILE *f;
	char id[30];
	windowtrgestion0=lookup_widget(widget,"windowtrgestion0");
	gtk_widget_destroy(windowtrgestion0);
	windowtrmodifier0= create_trmodifier0();
	combo=lookup_widget(windowtrmodifier0,"comboboxtr3");
	f=fopen("troupeau.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*d %*d %*d\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
	gtk_widget_show(windowtrmodifier0);
       

}



void
on_FKretour2_clicked                   (GtkWidget      *widget,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrconsulter2, *treeviewtr2;
windowtrconsulter2=lookup_widget(widget,"windowtrconsulter2");
gtk_widget_hide(windowtrconsulter2);
windowtrgestion0=create_trgestion0();
gtk_widget_show (windowtrgestion0);
treeviewtr2=lookup_widget(windowtrgestion0,"treeviewtr2");

consulter (treeviewtr2);
}


void
on_FKrecherche2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output1, *output,*in1;
char id[10];
troupeau tr;
char nom[20];
char texte1 [200] ="";
char texte2 [200] ="";
char texte3 [200] ="";
char texte4 [200] ="";
int b=0, nb;
in1=lookup_widget(button, "entrytr6");
strcpy (id, gtk_entry_get_text (GTK_ENTRY(in1)));
FILE*f;
f=fopen("troupeau.txt","r");
if (x==1){
if (f!= NULL)
{
while (fscanf (f," %s %s %s %s %s %d %d %d",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,&tr.date.j,&tr.date.mo,&tr.date.a)!=EOF)
{ if (strcmp (id,tr.ID)==0)
sprintf(texte1,"Ce troupeau est existe");

}

output=lookup_widget(button,("labeltr14"));
gtk_label_set_text(GTK_LABEL(output),texte1);

}}
if (x==2){
if (f!= NULL)
{
while( fscanf (f," %s %s %s %s %s %d %d %d",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,&tr.date.j,&tr.date.mo,&tr.date.a)!=EOF)
{ if (strcmp (id,tr.etat)==0)
sprintf(texte1,"Ce troupeau est existe"); 

}

output=lookup_widget(button,("labeltr14"));
gtk_label_set_text(GTK_LABEL(output),texte1);
output1=lookup_widget(button,("labeltr51"));
gtk_label_set_text(GTK_LABEL(output1),texte2);

fclose (f);

}}}
/*void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t[0]=1;}
}



void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t[1]=1;}
}
*/


void
on_FKsuprimer30_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *in1;
troupeau tr;
char id[10];
GtkWidget *output;
in1=lookup_widget(button, "FKentry1");
output=lookup_widget(button,"labeltr18");
strcpy (id, gtk_entry_get_text (GTK_ENTRY(in1)));

FILE*f=NULL;
FILE*f1=NULL;
f=fopen("troupeau.txt","r");
f1=fopen("tmp.txt","w");
while (fscanf (f," %s %s %s %s %s %d %d %d",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,&tr.date.j,&tr.date.mo,&tr.date.a)!=EOF)

{
        if((strcmp(tr.ID,id)!=0))
        {
	fprintf(f1," %s %s %s %s %s %d %d %d\n",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,tr.date.j,tr.date.mo,tr.date.a);

gtk_label_set_text(GTK_LABEL(output),"Suppression Réussie !");
}

}
fclose(f);
fclose(f1);
remove("troupeau.txt");
rename("tmp.txt","troupeau.txt");
 }



void
on_FKajouter10_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *in1, *in2, *in3, *radiobuttontrmale,*ajouttr,
   *radiobuttontrf,*in5,*in6,*in7,*in8,*FKajouter;
GtkWidget *chekbuttonh;
GtkWidget *chekbuttone;
GtkWidget *chekbuttong;
GtkWidget *output;
output=lookup_widget(objet,"ajouttr");
gtk_label_set_text(GTK_LABEL(output),"Ajouté avec succès !");
char nourriture[100];
troupeau tr;
FKajouter=lookup_widget(objet,"FKajouter");   
in1=lookup_widget(objet,"comboboxtrs");                                              
in2= lookup_widget (objet,"FKid1");
chekbuttonh=lookup_widget(objet, "chekbuttonh");
chekbuttone=lookup_widget(objet, "chekbuttone");
chekbuttong=lookup_widget(objet, "chekbuttong");
radiobuttontrmale=lookup_widget(objet, "radiobuttontrmale");
radiobuttontrf=lookup_widget(objet, "radiobuttontrf");
in5= lookup_widget (objet,"comboboxtr1");
in6= lookup_widget (objet,"spinbuttontr1");
in7= lookup_widget (objet,"spinbuttontr2");
in8= lookup_widget (objet,"spinbuttontr3");
strcpy (tr.etat,gtk_combo_box_get_active_text (GTK_COMBO_BOX(in1)));
strcpy (tr.ID, gtk_entry_get_text (GTK_ENTRY(in2)));
strcpy (tr.type,gtk_combo_box_get_active_text (GTK_COMBO_BOX(in5)));
if (t[0]==1)
{
strcat(tr.nourriture,"eau");
t[0]=0;}

if (t[1]==1)
{strcat(tr.nourriture,"herbe");
t[1]=0;}
if (t[2]==1)
{strcat(tr.nourriture,"grains");
t[2]=0;}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobuttontrmale))==TRUE)
 {strcat(tr.sexe, "male");}

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobuttontrf))==TRUE)
 {strcpy(tr.sexe, "femelle");} 
tr.date.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (in6));
tr.date.mo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (in7));
tr.date.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (in8));
FILE *f;
f=fopen("troupeau.txt","a+");
if (f!=NULL){
fprintf  (f," %s %s %s %s %s %d %d %d \n",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,tr.date.j,tr.date.mo,tr.date.a) ;
fclose (f); }
}


void
on_treeviewtr1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


GtkTreeIter iter;
gchar *etat;
gchar *id ;
gchar *nourriture; 
gchar *type;
gint *sexe; 
gint *date;

troupeau tr;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model, &iter, path)) {
	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&etat,1,&id,2,&nourriture,3,&type,4,date,5,&sexe,-1);
	strcpy(tr.etat,etat);
	strcpy(tr.ID,id);
	strcpy(tr.nourriture,nourriture);
	strcpy(tr.type,type);
        strcpy(tr.sexe,sexe);
	strcpy(tr.date.j,date);

consulter (treeview);
}
}


void
on_radiobuttontri_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}
}


void
on_radiobuttontrt_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}
}


void
on_FKmodifier20_clicked                (GtkButton       *button,
                                        gpointer         user_data)

{
char id [10];
int b=0;
GtkWidget *in1,*in2 ,*in3,*in4, *in5, *in6,*in7 ,*in8, *FKmodifier , *output; 
troupeau tr;
in1=lookup_widget (button,"comboboxtr3");
FILE*f;
FILE*f1;
f=fopen("troupeau.txt","r");
f1=fopen("tmp.txt","w");
strcpy (id, gtk_combo_box_get_active_text (GTK_COMBO_BOX(in1)));
while (fscanf (f," %s %s %s %s %s %d %d %d",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,&tr.date.j,&tr.date.mo,&tr.date.a)!=EOF)
{
        if((strcmp(tr.ID,id)!=0)) { 
  fprintf(f1,"%s %s %s %s %s %d %d %d \n",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,tr.date.j,tr.date.mo,tr.date.a);}
 if((strcmp(tr.ID,id)==0)) {
in2= lookup_widget (button,"comboboxme");
in3= lookup_widget (button,"comboboxmn");
in4= lookup_widget (button,"comboboxms");
in5= lookup_widget (button,"comboboxtr2");
in6= lookup_widget (button,"spinbuttontr4");
in7= lookup_widget (button,"spinbuttontr5");
in8= lookup_widget (button,"spinbuttontr6");
strcpy (tr.etat,gtk_combo_box_get_active_text (GTK_COMBO_BOX(in2)));
strcpy (tr.nourriture,gtk_combo_box_get_active_text (GTK_COMBO_BOX(in3)));
strcpy (tr.sexe,gtk_combo_box_get_active_text (GTK_COMBO_BOX(in4)));
tr.date.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (in6));
tr.date.mo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (in7));
tr.date.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (in8));
strcpy (tr.type,gtk_combo_box_get_active_text (GTK_COMBO_BOX(in5)));
	output=lookup_widget(button,"labeltr42");
        gtk_label_set_text(GTK_LABEL(output),"Modification réussite !");

        fprintf(f1,"%s %s %s %s %s %d %d %d \n",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,tr.date.j,tr.date.mo,tr.date.a);
}}

fclose(f);
fclose(f1);
remove("troupeau.txt");
rename("tmp.txt","troupeau.txt");
}


void
on_FKretour20_enter                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrmodifier0, *treeviewtr2;
windowtrmodifier0=lookup_widget(button,"windowtrmodifier0");
gtk_widget_hide(windowtrmodifier0);
windowtrgestion0=create_trgestion0();
gtk_widget_show (windowtrgestion0);
treeviewtr2=lookup_widget(windowtrgestion0,"treeviewtr2");

consulter (treeviewtr2);
}

void 
on_buttontr15_clicked                    (GtkWidget      *widget,
                                        gpointer         user_data)
//retour
{

GtkWidget *windowtrgestion0, *windowtrsuprimer3, *treeviewtr2;
windowtrsuprimer3=lookup_widget(widget,"windowtrsuprimer3");

gtk_widget_destroy(windowtrsuprimer3);
windowtrsuprimer3=lookup_widget(widget,"windowtrsuprimer3");
windowtrgestion0=create_trgestion0();
gtk_widget_show(windowtrgestion0);

treeviewtr2=lookup_widget(windowtrgestion0,"treeviewtr2");
consulter (treeviewtr2);}


// NB troupeaux
void
on_button17tr_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *in1 , *output ;
int nb =0,i;
char type [10];
char texte [200]="";
FILE *f =NULL;
troupeau tr; 
f= fopen ("troupeau.txt","r");
in1= lookup_widget (button,"comboboxtrnbre");
strcpy (type,gtk_combo_box_get_active_text (GTK_COMBO_BOX(in1)));
if (f!= NULL)
{ 
while (fscanf (f," %s %s %s %s %s %d %d %d",tr.ID,tr.type,tr.sexe,tr.nourriture,tr.etat,&tr.date.j,&tr.date.mo,&tr.date.a)!=EOF)
{ if (strcmp (type,tr.type)==0)
nb+=1;} 
sprintf (texte,"Le nombre des troupeaux de ce type est : %d",nb);
output=lookup_widget(button,("labeltr41"));
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
return (nb);}
}

void
on_buttontr18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowtrgestion0, *windowtrnbre, *treeviewnbrt;
windowtrgestion0=lookup_widget(button,"windowtrgestion0");
gtk_widget_hide(windowtrgestion0);
windowtrnbre=create_trnbre();
gtk_widget_show (windowtrnbre);
treeviewnbrt=lookup_widget(windowtrnbre,"treeviewnbrt");
consulter (treeviewnbrt);
}


void
on_Chercher_clicked                   (GtkWidget      *widget,
                                        gpointer         user_data)

{
GtkWidget *windowtrgestion0, *windowtrrecherche, *treeviewtr4;
windowtrgestion0=lookup_widget(widget,"windowtrgestion0");
gtk_widget_hide(windowtrgestion0);
windowtrrecherche=create_trrecherche();
gtk_widget_show (windowtrrecherche);
treeviewtr4=lookup_widget(windowtrrecherche,"treeviewtr4");

consulter (treeviewtr4);
}

void
on_radiobuttontrmale_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttontrf_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbuttone_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
 {t[0]=1;}

}

void
on_checkbuttonh_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
 {t[1]=1;}

}


void
on_checkbuttong_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
 {t[2]=1;}

}


/*void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}*/


void
on_buttontrnbre_clicked                (GtkWidget      *widget,
                                        gpointer         user_data)
{

GtkWidget *windowtrgestion0, *windowtrnbre, *treeviewtr2;
windowtrnbre=lookup_widget(widget,"windowtrnbre");

gtk_widget_destroy(windowtrnbre);
windowtrnbre=lookup_widget(widget,"windowtrnbre");
windowtrgestion0=create_trgestion0();
gtk_widget_show(windowtrgestion0);

treeviewtr2=lookup_widget(windowtrgestion0,"treeviewtr2");
consulter (treeviewtr2);}


void
on_buttontrch_clicked                  (GtkWidget      *widget,

                                      gpointer         user_data)
{

GtkWidget *windowtrgestion0, *windowtrrecherche;
GtkWidget *treeviewtr2;
windowtrrecherche=lookup_widget(widget,"windowtrrecherche");

gtk_widget_destroy(windowtrrecherche);
windowtrrecherche=lookup_widget(widget,"windowtrrecherche");
windowtrgestion0=create_trgestion0();
gtk_widget_show(windowtrgestion0);

treeviewtr2=lookup_widget(windowtrgestion0,"treeviewtr2");
consulter (treeviewtr2);}




void
on_buttontout_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
int nbrt=0;
int c;
char texte[200]="";
FILE *f=NULL;
f=fopen("troupeau.txt","r");
while((c=fgetc(f))!=EOF)
{
if(c=='\n')
nbrt++;
}
sprintf (texte,"Le nombre totale des troupeaux est : %d",nbrt);
output=lookup_widget(button,("label1919"));
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
}
void
on_gestrp_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{
{GtkWidget *Admin,*trgestion0; 
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
trgestion0=create_trgestion0();
gtk_widget_show(trgestion0);
}
}
int x;
int y;

void
on_ajouter1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
client c;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input8,*produit;	
GtkWidget *ajout_cl;
GtkWidget *output3;
int b;
output3=lookup_widget(objet_graphique,"label1935");
ajout_cl=lookup_widget(objet_graphique,"ajout_cl");	
input1=lookup_widget(objet_graphique,"entry150");
input2=lookup_widget(objet_graphique,"entry160");
input3=lookup_widget(objet_graphique,"entry170");
input4=lookup_widget(objet_graphique,"entry180");
input5=lookup_widget(objet_graphique,"entry190");
input6=lookup_widget(objet_graphique,"entry200");
input8=lookup_widget(objet_graphique,"entry210");
produit=lookup_widget(objet_graphique,"entry220");



strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.dnaissance,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(c.n_tel,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(c.produit,gtk_combo_box_get_active_text(GTK_COMBO_BOX(produit)));
printf(gtk_combo_box_get_active_text(GTK_COMBO_BOX(produit)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input1)));

if(x==0)
{strcpy(c.sexe,"Homme");}
else
if(x==1)
{strcpy(c.sexe,"Femme");}
ajouter_client(c);
b=1;
gtk_label_set_text(GTK_LABEL(output3),"Ajout Réussie !");
}


void
on_afficher1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajout_cl;
GtkWidget *affiche_cl;
GtkWidget *treeview11;


ajout_cl=lookup_widget(objet,"ajout_cl");
gtk_widget_destroy(ajout_cl);
affiche_cl=lookup_widget(objet,"affiche_cl");
affiche_cl=create_affiche_cl();
gtk_widget_show(affiche_cl);
treeview11=lookup_widget(affiche_cl,"treeview11");
afficher_client(treeview11);

}


void
on_treeview11_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)

{		
		GtkTreeIter iter;
		gchar* id;
		gchar* nom;
		gchar* prenom;
		gchar* dnaissance;
		gchar* email;
		gchar* cin;
		gchar* n_tel;
		gchar* sexe;
		gchar* produit;
		client c;
		
		
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path)) {
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&prenom,3,&dnaissance,4,&email,5,&cin,6,&n_tel,7,&sexe,8,&produit,-1);
strcpy(c.id,id);
strcpy(c.nom,nom);
strcpy(c.prenom,prenom);
strcpy(c.dnaissance,dnaissance);
strcpy(c.email,email);
strcpy(c.cin,cin);
strcpy(c.n_tel,n_tel);
strcpy(c.sexe,sexe);
strcpy(c.produit,produit);

afficher_client(treeview);

}}

void
on_retourcl_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)

{
GtkWidget *ajout_cl,*affiche_cl;
affiche_cl=lookup_widget(objet,"affiche_cl");
gtk_widget_destroy(affiche_cl);
ajout_cl=create_ajout_cl();
gtk_widget_show(ajout_cl);
}



void
on_supprimer1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)

{GtkWidget *ajout_cl,*supprim_cl;
GtkWidget *combo;
	FILE *f;
	char id[30];
ajout_cl=lookup_widget(objet,"ajout_cl");
gtk_widget_destroy(ajout_cl );
supprim_cl=create_supprim_cl();
combo=lookup_widget(supprim_cl,"entry400");
	f=fopen("client.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s %*s %*s\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(supprim_cl);
}



void
on_retour_supp_cl_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *supprim_cl,*ajout_cl; 
supprim_cl=lookup_widget(objet,"supprim_cl");
gtk_widget_destroy(supprim_cl);
ajout_cl=create_ajout_cl();
gtk_widget_show(ajout_cl);
}


void
on_modifier1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)

{GtkWidget *ajout_cl,*modif_cl;
GtkWidget *combo;
	FILE *f;
	char id[30];

ajout_cl=lookup_widget(objet,"ajout_cl");
gtk_widget_destroy(ajout_cl);
modif_cl=create_modif_cl();
combo=lookup_widget(modif_cl,"entry300");
	f=fopen("client.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*s %*s %*s %*s %*s\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
gtk_widget_show(modif_cl);
}

void
on_confirmer1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)

{	client c;
GtkWidget *input;
GtkWidget *output;
output=lookup_widget(objet,"label1951");
int b;
input= lookup_widget(objet,"entry400");
strcpy(c.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
Supprimer_client(c);
b=1;
gtk_label_set_text(GTK_LABEL(output),"Suppression Réussie !");
}


void
on_retour_modif_cl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)

{
GtkWidget *modif_cl,*ajout_cl;
modif_cl=lookup_widget(objet,"modif_cl");
gtk_widget_destroy(modif_cl);
ajout_cl=create_ajout_cl();
gtk_widget_show(ajout_cl);
}


void
on_modif1_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;
GtkWidget *modif_cl; 	
GtkWidget *id,*nom,*prenom,*dnaissance,*email,*cin,*n_tel,*sexe,*produit;
GtkWidget *output2;
output2=lookup_widget(objet,"label1947");
int b;
modif_cl=lookup_widget(objet,"modif_cl");
id= lookup_widget(objet,"entry300");
nom= lookup_widget(objet,"entry310");
prenom= lookup_widget(objet,"entry320");
dnaissance=lookup_widget(objet,"entry330");
email=lookup_widget(objet,"entry340");
cin=lookup_widget(objet,"entry350");
n_tel=lookup_widget(objet,"entry360");
sexe=lookup_widget(objet,"entry370");
produit=lookup_widget(objet,"entry380");

strcpy(c.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(c.dnaissance,gtk_entry_get_text(GTK_ENTRY(dnaissance)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(c.n_tel,gtk_entry_get_text(GTK_ENTRY(n_tel)));
strcpy(c.sexe,gtk_entry_get_text(GTK_ENTRY(sexe)));
strcpy(c.produit,gtk_combo_box_get_active_text(GTK_COMBO_BOX(produit)));
Modifier_client(c);
b=1;
gtk_label_set_text(GTK_LABEL(output2),"Modification Réussie !");
}

  
void
on_radiobutton1_homme1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=0;
}
}
void
on_radiobutton2_femme1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)

{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}
void
on_Gestion_des_clients_clicked         (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Admin,*ajout_cl; 
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
ajout_cl=create_ajout_cl();
gtk_widget_show(ajout_cl);
}
int x;
void
on_treeview_capt_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* id;
	gchar* marque;
	gchar* type;
	gchar* etat_def;
	gint* val_min;
	gint* val_max;
	capteur capt;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter, path))
{
gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &id, 1, &marque, 2, &type, 3, &etat_def, 4, &val_min, 5, &val_max, -1);
strcpy(capt.id,id);
strcpy(capt.marque,marque);
strcpy(capt.type,type);
strcpy(capt.etat_def,etat_def);
capt.val_min=val_min;
capt.val_max=val_max;
afficher_capteurs(treeview);
}
}



void
on_treeview_alarm_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)

{
	GtkTreeIter iter;
	gint* id;
	gfloat *valeur;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter, path))
{
gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &id, 1, &valeur  -1);

afficher_alarmantes(treeview);
}
}


void
on_ajouter_capt_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ajouter_capteur;
	GtkWidget *gestion_capteur;
	gestion_capteur=lookup_widget(objet,"gestion_capteur");
	gtk_widget_destroy(gestion_capteur);
	ajouter_capteur = create_ajouter_capteur();
	gtk_widget_show(ajouter_capteur);
}


void
on_modifier_capt_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
 	GtkWidget *gestion_capteur;
	GtkWidget *modifier_capteur;
	GtkWidget *combo;
	FILE *f;
	char id[30];
	gestion_capteur=lookup_widget(objet,"gestion_capteur");
	gtk_widget_destroy(gestion_capteur);
	modifier_capteur = create_modifier_capteur();
	combo=lookup_widget(modifier_capteur,"cb_id_modif");
	f=fopen("capteur.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*d %*d\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
	gtk_widget_show(modifier_capteur);
}

void
on_supprimer_capt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
 	GtkWidget *gestion_capteur;
	GtkWidget *supprimer_capteur;
	GtkWidget *combo;
	FILE *f;
	char id[30];
	gestion_capteur=lookup_widget(objet,"gestion_capteur");
	gtk_widget_destroy(gestion_capteur);
	supprimer_capteur = create_supprimer_capteur();
	combo=lookup_widget(supprimer_capteur,"combobox_supp");
	f=fopen("capteur.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*d %*d\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
	gtk_widget_show(supprimer_capteur);

}


void
on_parametre_capt_clicked              (GtkWidget     *objet,
                                        gpointer         user_data)
{
GtkWidget *gestion_capteur;
GtkWidget *parametres;
GtkWidget *treeview_param;
gestion_capteur=lookup_widget(objet,"gestion_capteur");

gtk_widget_destroy(parametres);
parametres=lookup_widget(objet,"parametres");
parametres=create_parametres();

gtk_widget_show(parametres);

treeview_param=lookup_widget(parametres,"treeview_param");

afficher_parametres(treeview_param);

}


void
on_Ajout_ok_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
capteur capt;
	
GtkWidget *marque,*type,*id;
GtkWidget *output3;
output3=lookup_widget(objet,"label1965");
int b;
marque= lookup_widget(objet,"entry_marque");
id= lookup_widget(objet,"entry_id");
strcpy(capt.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
printf(gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
if(x==0)
{strcpy(capt.type,"temperature");}
else
if(x==1)
{strcpy(capt.type,"Humidite");}
strcpy(capt.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(capt.etat_def,"N/A");
b=1;
gtk_label_set_text(GTK_LABEL(output3),"Ajout Réussie !");
ajouter_capteur(capt);
}


void
on_retour_ajout_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_capteur;
GtkWidget *gestion_capteur;
GtkWidget *treeview_capt;
ajouter_capteur=lookup_widget(objet,"ajouter_capteur");

gtk_widget_destroy(ajouter_capteur);
gestion_capteur=lookup_widget(objet,"gestion_capteur");
gestion_capteur=create_gestion_capteur();
gtk_widget_show(gestion_capteur);

treeview_capt=lookup_widget(gestion_capteur,"treeview_capt");

afficher_capteurs(treeview_capt);
}


void
on_modif_ok_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	capteur capt;
	
GtkWidget *marque,*type,*id;
GtkWidget *output2;
output2=lookup_widget(objet,"label1972");
int b;
id= lookup_widget(objet,"cb_id_modif");
marque= lookup_widget(objet,"entry_marque_modif");
type= lookup_widget(objet,"cb_type_modif");
strcpy(capt.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(capt.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(capt.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
b=1;
gtk_label_set_text(GTK_LABEL(output2),"Modification Réussie !");

modifier_capteur(capt);
}


void
on_retour_modif_capt_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
		
GtkWidget *modifier_capteur;
GtkWidget *gestion_capteur;
GtkWidget *treeview_capt;
modifier_capteur=lookup_widget(objet,"modifier_capteur");

gtk_widget_destroy(modifier_capteur);
gestion_capteur=lookup_widget(objet,"gestion_capteur");
gestion_capteur=create_gestion_capteur();
gtk_widget_show(gestion_capteur);

treeview_capt=lookup_widget(gestion_capteur,"treeview_capt");

afficher_capteurs(treeview_capt);
}

void
on_supprim_ok_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{	capteur capt;
GtkWidget *input;
GtkWidget *output;
output=lookup_widget(objet,"label1977");
int b;
input= lookup_widget(objet,"combobox_supp");
strcpy(capt.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
supprimer_capteur(capt);
b=1;
gtk_label_set_text(GTK_LABEL(output),"Suppression Réussie !");
}



void
on_retour_supp_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *supprimer_capteur;
GtkWidget *gestion_capteur;
GtkWidget *treeview_capt;
supprimer_capteur=lookup_widget(objet,"supprimer_capteur");

gtk_widget_destroy(supprimer_capteur);
gestion_capteur=lookup_widget(objet,"gestion_capteur");
gestion_capteur=create_gestion_capteur();
gtk_widget_show(gestion_capteur);

treeview_capt=lookup_widget(gestion_capteur,"treeview_capt");

afficher_capteurs(treeview_capt);

}



void
on_treeview_param_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gint* id;
	date* date_enr;
	horaire* horaire_enr;
	gfloat *valeur;
	parametres param;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter, path))
{
gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &id, 1, &date_enr, 2, &horaire_enr, 3, &valeur  -1);

afficher_parametres(treeview);
}
}

void
on_ajout_param_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_parametres, *parametres;
	GtkWidget *combo;
	FILE *f;
	char id[30];
	parametres=lookup_widget(objet,"parametres");
	gtk_widget_destroy(parametres);
	ajouter_parametres = create_ajouter_parametres();
	combo=lookup_widget(ajouter_parametres,"cb_id");
	f=fopen("capteur.txt","r");
	while(fscanf(f,"%s %*s %*s %*s %*d %*d\n",id)!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(combo),id);
	}
	fclose(f);
	gtk_widget_show(ajouter_parametres);
}
void
on_param_ok_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
parametres param;

	GtkWidget *id, *jour, *mois, *annee, *heure, *minute, *val;
	id=lookup_widget(objet,"cb_id");
	jour=lookup_widget(objet,"spinbutton_jour");
	mois=lookup_widget(objet,"spinbutton_mois");
	annee=lookup_widget(objet,"spinbutton_annee");
	heure=lookup_widget(objet,"spinbutton_heure");
	minute=lookup_widget(objet,"spinbutton_minute");
	val=lookup_widget(objet,"entry_val");
	
	strcpy(param.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
param.dateE.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
param.dateE.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
param.dateE.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
param.horaireE.heure=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(heure));
param.horaireE.minute=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(minute));
param.valeur=atof(gtk_entry_get_text(GTK_ENTRY(val)));

ajouter_parametres(param);
}


void
on_retour_param_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_parametres;
GtkWidget *parametres;
GtkWidget *treeview_param;
ajouter_parametres=lookup_widget(objet,"ajouter_parametres");

gtk_widget_destroy(ajouter_parametres);
parametres=lookup_widget(objet,"parametres");
parametres=create_parametres();
gtk_widget_show(parametres);

treeview_param=lookup_widget(parametres,"treeview_param");

afficher_parametres(treeview_param);
}


void
on_temperature_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=0;
}
}


void
on_humidite_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_alarmantes_clicked                      (GtkButton      *button,
                                        gpointer         user_data)

{
GtkWidget  *output ;
int nb=0,i;
char etat_def[30];
char texte [200]="";
FILE *f =NULL;
capteur capt; 
f= fopen ("capteur.txt","r");
if (f!= NULL)
{ 
while (fscanf (f," %s %s %s %s %d %d\n",capt.id,capt.marque,capt.type,capt.etat_def,&capt.val_min,&capt.val_max)!=EOF)
{ if (strcmp (capt.etat_def,"Alarmantes")==0)
nb+=1;
}
sprintf (texte,"Le nombre des capteurs ayant des valeurs alarmantes est: %d",nb);
output=lookup_widget(button,("label1959"));
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
return (nb);
}
}

/*
void
on_defec_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *chemin;
FILE *f =NULL;
GtkWidget  *output;
char texte[200]="";
int i;
capteur capt;
while (fscanf (f," %s %s %s %s %d %d\n",capt.id,capt.marque,capt.type,capt.etat_def,&capt.val_min,&capt.val_max)!=EOF)
{sprintf(texte,"le capteur avec l identifiant %d est le plus defaillant\n",i);}
output=lookup_widget(objet,("label110"));
gtk_label_set_text(GTK_LABEL(output),texte);
defectueux(chemin);
fclose(f);
}*/






void
on_gestion_des_capteurs_clicked        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Admin,*gestion_capteur; 
Admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(Admin);
gestion_capteur=create_gestion_capteur();
gtk_widget_show(gestion_capteur);
}

