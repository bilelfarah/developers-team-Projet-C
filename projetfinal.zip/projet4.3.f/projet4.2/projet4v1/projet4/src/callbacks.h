#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retouremp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_supp_emp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_modif_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_radiobutton1_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_Connexion_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_Ajout_admin_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_Modifier_admin_clicked              (GtkButton       *objet,
                                        gpointer         user_data);

void
on_Supprimer_admin_clicked             (GtkButton       *objet,
                                        gpointer         user_data);

void
on_Afficher_admin_clicked              (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_admin_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

void
on_Inscription_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_enregistrer_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_inscri_clicked               (GtkButton       *objet,
                                        gpointer         user_data);

void
on_deconnexion_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ajouter_admin_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_admin1_clicked               (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_Valider_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_Abseent_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_treeview2_absent_row_activated      (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affiche_absent_clicked              (GtkButton       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Retour_absentisme_clicked           (GtkButton       *objet,
                                        gpointer         user_data);


void
on_calcul_absent_mois_clicked          (GtkButton       *button,
                                        gpointer         user_data);
//troupeau
void
on_FKretour1_clicked                  (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_FKajouter0_clicked                  (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_FKsuprimer0_clicked                (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_FKconsulter0_clicked                (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_FKmodifier0_clicked                 (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_treeviewtr1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_FKretour2_clicked                   (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_FKrecherche2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/

/*void
on_FKsuprimer3_clicked                 (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_FKsuprimer30_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_FKajouter_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_FKajouter10_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeviewtr1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobuttontri_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttontrt_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FKmodifier20_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_FKretour20_enter                    (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_buttontr15_clicked                    (GtkWidget      *widget,
                                        gpointer         user_data);

/*void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_button17tr_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttontr18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_clicked                    (GtkWidget      *widget,
                                        gpointer         user_data);


void
on_radiobuttontrmale_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttontrf_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttone_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonh_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttong_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeviewtr1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttontrnbre_clicked                (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_buttontrch_clicked                  (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_treeviewtr1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttontout_clicked                  (GtkButton       *button,
                                        gpointer         user_data);





void
on_treeviewtr1_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttontr18_clicked                  (GtkButton       *button,
                                        gpointer         user_data);




void
on_gestrp_clicked                      (GtkButton       *objet,
                                        gpointer         user_data);
//client


void
on_ajouter1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_afficher1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview11_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retourcl_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_supp_cl_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmer1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_modif_cl_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_modif1_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_radiobutton1_homme1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_femme1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_Gestion_des_clients_clicked         (GtkButton       *objet,
                                        gpointer         user_data);
void
on_treeview_capt_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview_alarm_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajouter_capt_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_capt_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer_capt_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_parametre_capt_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ajout_ok_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_ajout_clicked                (GtkWidget       *button,
                                        gpointer         user_data);


void
on_modif_ok_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_modif_capt_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_supprim_ok_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);


void
on_retour_supp_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview_param_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajout_param_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_param_ok_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_param_clicked                (GtkWidget       *button,
                                        gpointer         user_data);


void
on_temperature_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_humidite_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_alarmantes_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_defec_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);*/



void
on_gestion_des_capteurs_clicked        (GtkButton       *objet,
                                        gpointer         user_data);
